V2 COMPLETE — version statique sans crédit Lovable. 16 étapes, localStorage, 3 jokers, cartes, 4 accès équipe.

IMPORTANT: les réponses visuelles ont été fixées à partir des éléments locaux/publics documentés et de photos disponibles en ligne. Avant le jour J, faire un passage de 10 minutes sur les 6 lieux pour vérifier que les éléments visuels (signalétique et façade) sont toujours visibles.
